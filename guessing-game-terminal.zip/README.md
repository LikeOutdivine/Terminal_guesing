# 🎯 Jogo de Adivinhação no Terminal

Um jogo simples e divertido de adivinhação feito em Python. O objetivo é adivinhar um número secreto entre 1 e 100 com o menor número de tentativas possível.

## 📋 Descrição

Este jogo roda no terminal e foi desenvolvido para praticar lógica de programação, entrada de dados e controle de fluxo com Python. A cada tentativa, o programa informa se o número secreto é maior ou menor que o palpite do jogador.

## 🕹️ Como jogar

1. Clone o repositório:

```bash
git clone https://github.com/seu-usuario/guessing-game-terminal.git
cd guessing-game-terminal
```

2. Execute o jogo com Python 3:

```bash
python guessing_game.py
```

## 📌 Regras

- O número secreto é um inteiro aleatório entre 1 e 100.
- O jogador deve digitar palpites até acertar.
- O programa informa se o número secreto é maior ou menor que o palpite atual.

## 💻 Requisitos

- Python 3 instalado no sistema (https://www.python.org)

## 📂 Estrutura dos arquivos

```
guessing-game-terminal/
├── guessing_game.py   # Código principal do jogo
└── README.md          # Instruções e informações do projeto
```

## 🚀 Próximos passos (opcional)

- Adicionar sistema de pontuação
- Implementar um modo difícil com limite de tentativas
- Salvar o histórico de tentativas em arquivo

## 🧑‍💻 Autor

Desenvolvido por **[Seu Nome ou Nome de Usuário]**  
GitHub: [https://github.com/seu-usuario](https://github.com/seu-usuario)

---

Feito com 💙 em Python
