import random

def jogar():
    print("==== Jogo de Adivinhação ====")
    print("Tente adivinhar o número secreto entre 1 e 100")

    numero_secreto = random.randint(1, 100)
    tentativas = 0

    while True:
        try:
            chute = int(input("Digite seu palpite: "))
            tentativas += 1

            if chute < 1 or chute > 100:
                print("Por favor, digite um número entre 1 e 100.")
                continue

            if chute == numero_secreto:
                print(f"Parabéns! Você acertou o número {numero_secreto} em {tentativas} tentativa(s).")
                break
            elif chute < numero_secreto:
                print("O número secreto é maior.")
            else:
                print("O número secreto é menor.")
        except ValueError:
            print("Por favor, digite um número válido.")

if __name__ == "__main__":
    jogar()
